import React, { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import ModeSelector from "./components/ModeSelector.jsx";
import PracticeMode from "./components/PracticeMode.jsx";
import InterviewMode from "./components/InterviewMode.jsx";

export default function App() {
  const [view, setView] = useState("dashboard"); // dashboard | practice | interview

  return (
    <div className="app-shell">
      <Navbar view={view} onNavigate={setView} />

      <main className="app-main">
        {view === "dashboard" && <ModeSelector onSelect={setView} />}
        {view === "practice" && <PracticeMode />}
        {view === "interview" && <InterviewMode onNavigateToPractice={() => setView("practice")} />}
      </main>

      <footer className="app-footer">
        <span>VocaPrep — AI Communication Coach</span>
      </footer>
    </div>
  );
}
