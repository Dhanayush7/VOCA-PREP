// src/services/api.js
//
// Every call the frontend makes to our Express backend lives here.
// The frontend never talks to Sarvam directly and never sees an API key.

const API_URL = "http://localhost:5001";

async function handleResponse(response) {
  let body = null;
  try {
    body = await response.json();
  } catch (_) {
    // non-JSON response (e.g. server crashed) - fall through to generic error
  }

  if (!response.ok) {
    const message =
      (body && body.error) || `Request failed with status ${response.status}.`;
    const error = new Error(message);
    error.code = body && body.code;
    error.status = response.status;
    throw error;
  }

  return body;
}

/**
 * Sends a recorded audio Blob to the backend for transcription.
 * @param {Blob} audioBlob
 * @returns {Promise<{transcript: string}>}
 */
export async function speechToText(audioBlob) {
  const formData = new FormData();
  const extension = audioBlob.type.includes("mp4") ? "mp4" : "webm";
  formData.append("audio", audioBlob, `recording.${extension}`);

  let response;
  try {
    response = await fetch(`${API_URL}/api/speech-to-text`, {
      method: "POST",
      body: formData,
    });
  } catch (networkErr) {
    throw new Error("Couldn't reach the VocaPrep server. Is it running on port 5001?");
  }

  return handleResponse(response);
}

/**
 * Evaluates a transcribed answer for a given question.
 * @param {string} question
 * @param {string} transcript
 * @param {"practice"|"interview"} mode
 */
export async function evaluateAnswer(question, transcript, mode = "practice") {
  let response;
  try {
    response = await fetch(`${API_URL}/api/evaluate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, transcript, mode }),
    });
  } catch (networkErr) {
    throw new Error("Couldn't reach the VocaPrep server. Is it running on port 5001?");
  }

  return handleResponse(response);
}

/**
 * Requests the next interview question from the AI.
 * @param {{type: string, questionNumber: number, previousQuestions: string[], previousAnswers: string[]}} data
 */
export async function generateInterviewQuestion(data) {
  let response;
  try {
    response = await fetch(`${API_URL}/api/interview/question`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
  } catch (networkErr) {
    throw new Error("Couldn't reach the VocaPrep server. Is it running on port 5001?");
  }

  return handleResponse(response);
}

/**
 * Requests the final interview report built from real collected data.
 * @param {{interviewType: string, questions: string[], answers: string[], evaluations: object[]}} data
 */
export async function generateInterviewReport(data) {
  let response;
  try {
    response = await fetch(`${API_URL}/api/interview/report`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
  } catch (networkErr) {
    throw new Error("Couldn't reach the VocaPrep server. Is it running on port 5001?");
  }

  return handleResponse(response);
}
